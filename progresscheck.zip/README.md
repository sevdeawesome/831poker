
![](https://github.com/sevdeawesome/831poker/blob/main/art/new_logo.jpg)

# COMING SOON



## Authors:
 ### Severin Field
 - website
 - github
 
 ### Thomas Trenholme
 - [website]
 - github
 
 ### Nik Milcevski (Graphics)
 - website



## Technologies Used
- JavaScript
- Node JS
- HTML5, CSS3
- Socket IO
- Express
- Nodemon
- Github/git
- Adobe Illustrator


## Design Patterns:
 - Factory 
 - Singleton
 
 


